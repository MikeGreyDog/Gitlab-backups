#!/bin/bash

find . -name '*.yml' -exec yamlinit{} +
